#ifndef __TIMER_H
#define __TIMER_H

// Init timer
void timer_init();

// Get curr ticks value
volatile unsigned long int timer_ticks();

// Delay
void delay(int ms);

#endif
