#include <reg51.h>
#include "lcd.h"
#include "timer.h"

// LCD
sbit lcd1 = P1^0;
sbit lcd2 = P1^1;
sbit lcd3 = P1^2;
sbit lcd4 = P1^3;

// Cac so tren led 7 thanh
int numbs[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90, 0x88, 0x83, 0xC6, 0xA1, 0x86, 0x8E};

// last time show
unsigned long int last_show = 0;

// hien thi
//  numb: so can hien thi, radix: co so
void lcd_show(int numb, int radix, int nhay_lvl) {
	int show_time, nhay_time;
	unsigned long int delta;
	if(nhay_lvl == 0) {
		show_time = 0xFFFF; nhay_time = 0;
	} else if(nhay_lvl == 1) {
		show_time = 500; nhay_time = 700;
	} else {
		show_time = 300; nhay_time = 600;
	}
	// check time
	delta = timer_ticks() - last_show;
	if(delta > nhay_time)
		last_show = timer_ticks();
	else if(delta > show_time)
		return;
	// Show the numb
	P0 = numbs[numb % radix];
	numb /= radix;
	lcd4 = 0;
	delay(5);
	lcd4 = 1;
	P0 = numbs[numb % radix];
	numb /= radix;
	lcd3 = 0;
	delay(5);
	lcd3 = 1;
	P0 = numbs[numb % radix];
	numb /= radix;
	lcd2 = 0;
	delay(5);
	lcd2 = 1;
	P0 = numbs[numb % radix];
	lcd1 = 0;
	delay(5);
	lcd1 = 1;
}
