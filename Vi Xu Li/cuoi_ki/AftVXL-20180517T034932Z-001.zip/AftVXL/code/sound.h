#ifndef __SOUND_H
#define __SOUND_H

// check sound
int isSound();

// Thu tuc phat nhac voi tan so
void sound(int frequence);

// Tat am
void nosound();

#endif
