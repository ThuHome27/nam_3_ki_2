#ifndef __LCD_H
#define __LCD_H

// hien thi
//  numb: so can hien thi, radix: co so
void lcd_show(int numb, int radix, int nhay_lvl);

#endif
