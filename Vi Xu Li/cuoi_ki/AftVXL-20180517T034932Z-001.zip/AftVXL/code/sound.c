#include <reg51.h>
#include "sound.h"

// Loa
sbit loa = P1^5;

// Thuoc tinh cua loa
int timer1_high_byte = 0xFC;
int timer1_low_byte  = 0x66;

// bit bat loa
char sound_on = 0;

// checkSound
int isSound() {
   return sound_on;
}

// Thu tuc phat nhac voi tan so
void sound(int frequence) {
	unsigned int div;

	// Neu dang bat -> return
	if(sound_on)
		return;
	
	// Set sound
	sound_on = 1;
	
	// Bat am
	div = 0xFFFF-1105920/frequence/12;

	timer1_high_byte = (div >> 8) & 0xFF;
	timer1_low_byte  = div & 0xFF;

	TMOD |= 0x10; // Timer 1 Mode 1

	TH1 = timer1_high_byte;
	TL1 = timer1_low_byte;

	TR1 = 1; // Timer 0 Run
	ET1 = 1; // Ennable Timer 0 interrupt
}

// Tat am
void nosound() {
	// Neu dang tat -> return
	if(!sound_on)
		return;
	
	// Set sound_off
	sound_on = 0;

    // stop timer
    TR1 = 0;                 // timer 1 off
    ET1 = 0;
    TMOD &= 0xF;
}

// Timer 1 Interrupt Handler
void timer1_ISR (void) interrupt 3 {
    // stop timer
    TR1 = 0;                 // timer 0 off
   
    // event processing here
    loa = !loa;

    // continue timer
    TH1 = timer1_high_byte; // reload timer 0 high byte
    TL1 = timer1_low_byte;  // reload timer 0 low byte 
    TR1 = 1;                // timer 0 run
}

