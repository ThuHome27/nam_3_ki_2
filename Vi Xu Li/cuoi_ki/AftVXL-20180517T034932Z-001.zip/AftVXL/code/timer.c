#include <reg51.h>
#include "timer.h"

// Gia tri TH0, TL0 de dinh thoi
// Timer Clock Cycle Duration = 6/oscillator frequency
// delay = Timer Delay / Timer Clock Cycle Duration
//       = 10^-3/(12/11.0592x10^6)
//       = 921
// Timer Reload Value = MaxRegCount - delay
//                    = 65535-921
//                    = 64614
//                    = 0xFC66
#define timer0_high_byte 0xFC
#define timer0_low_byte  0x66

// Timer counter
unsigned long int timer_counter = 0;

// Init timer
void timer_init() {
   TMOD = 0x1; // Timer 0 Mode 1

   TH0 = timer0_high_byte;
   TL0 = timer0_low_byte;
   
   timer_counter = 0; // Set counter to 0

   ET0 = 1; // Ennable timer0 interrupt
   TR0 = 1; // Timer 0 Run
}

// Timer Interrupt Handler
void timer0_ISR (void) interrupt 1 {
    TR0 = 0;                 // timer 0 off
   
    // event processing
    timer_counter++;

    // continue timer
    TH0 = timer0_high_byte; // reload timer 0 high byte
    TL0 = timer0_low_byte;  // reload timer 0 low byte 
    TR0 = 1;                // timer 0 run
}

// Get curr ticks value
unsigned long int timer_ticks() {
	return timer_counter;
}

// Delay
void delay(int ms) {
   unsigned long int max = timer_counter+ms;
   while(max > timer_counter);
}
